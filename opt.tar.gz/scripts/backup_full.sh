if  [[ $# -lt 2 || $1 == "-help" ]]; then 
	echo "$0 <origen> <destino>"
	exit 0
fi

if [[ ! -d "$1" ]]; then
	echo "el directorio de origen no existe"
	exit 0
fi

if [[ ! -d "$2" ]]; then
         echo "el directorio de destino no existe"
         exit 0
fi

fecha=$(date +%Y%m%d)

backup=$(basename "$1")_bkp_$fecha.tar.gz

tar -czf "$2/$backup" -C "$1" .

if [[ $? == 0 ]]; then
	echo "backup exitoso"
fi
